# Bem-vindo

A Taqtile é uma empresa que contribui para o desenvolvimento de estratégias mobile para centenas de marcas relevantes no mercado brasileiro e internacional. Isto só é possível pois todos colaboradores carregavam um senso crítico e uma preocupação de aprimoramento constante. Nosso objetivo é sempre manter o senso de qualidade, contando com pessoas totalmente alinhadas com nosso dever para com os clientes internos e externos.

# Escolha o seu desafio

O candidato pode escolher o desafio de acordo com a sua preferência:

- [Front-end](./frontend.md)

- [Back-end](./backend.md)
